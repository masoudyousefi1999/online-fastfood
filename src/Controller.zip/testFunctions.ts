// function generateVerificationCode(number){
//     const newCode = Math.floor(Math.random() * 9 * Math.pow(10, number - 1)) + Math.pow(10, number - 1);
//     return newCode;
// }

// const code =generateVerificationCode(5);

// console.log(code)